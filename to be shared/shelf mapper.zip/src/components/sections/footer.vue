<style>
.footer-credits {
  text-align: center;
  padding: 5px;
  display: none;
}
</style>
<template>
  <div class="hero-foot">
    <div class="container">
      <div class="is-centered footer-credits">
        made with <i class="fa fa-heart"></i> by
        <a href="#">dummy name</a>
      </div>
    </div>
  </div>
</template>
